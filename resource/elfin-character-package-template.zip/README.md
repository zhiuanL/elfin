# Elfin 角色包模板

这是一个可编辑的角色包模板 ZIP。

## 最低可运行资源
- manifest.json
- preview.png
- fallback.png
- animations/idle/ 至少 1 帧

## 建议制作流程
1. 替换 preview.png / fallback.png / animations 下的 PNG
2. 修改 manifest.json 中的 id、名称、描述、动画路径和能力声明
3. 按需修改 persona / dialogue / behavior / emotion / voice / hitarea 下的 JSON
4. 用你的 Elfin 程序导入 ZIP，查看校验结果并修正

## 图片建议
- 画布：512x512 PNG
- fallback / 动画：透明背景
- 序列帧命名：001.png、002.png、003.png

## 重要说明
- 这个模板是通用作者模板。
- 最终字段名和必填项请以你的仓库 docs/character-manifest.schema.json 为准。
- 如果你的当前 Schema 与本模板略有差异，请优先修改 manifest.json 来对齐。

## 目录说明
- animations/idle: 最低必需
- animations/blink happy rest talking: 常用可选动作
- animations/mouth-open / mouth-closed: 嘴型可选资源
- persona: 多语言人格配置示例
- dialogue: 多语言文案示例
- behavior / emotion / voice / hitarea: 高级能力示例
