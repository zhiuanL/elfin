Elfin 角色包模板：Schema 1 / 应用 0.2.0 兼容副本

使用：选择本 ZIP → 校验 → 导入 → 在角色列表选择后激活。
本副本不覆盖源 ZIP；所有 PNG 图片保持原始字节，不改画面或动画素材。
仍保留模板原来的 id 和角色名称。制作自己的角色时请改为唯一 id；同 id 已安装时应用会拒绝覆盖。

兼容转换：
- README.md 改为 README.txt；ZIP 根目录直接包含 manifest.json。
- declaredLevel → targetTier；能力和 Profile 字段按当前 Schema 命名。
- fallbackTo 数组转换成 fallback 链；嘴型 → talking → idle。
- Persona 姓名/关系/说话风格合入 summary，traits 保留；Dialogue 加 lines，pomodoro_complete → pomodoro-complete。
- Emotion 仅使用 animations 映射；原 default/states 作为作者备注保留在本文底部。
- Behavior 权重转换成 behaviors 列表，冷却毫秒转秒；未给出的 idle 冷却为 0。
- HitArea 按原 512×512 画布归一化。当前 Schema 只有矩形：head 的 ellipse 暂用其外接矩形；原形状记录保留在本文底部。
- Voice 字段重命名；原 rate=0 转成 speed=1，volume=100 转成 volume=1。voice 名称仍是作者占位值，并非已验证的系统语音。
- targetTier=full 只说明示例资源及元数据完整，不代表已实现行为、情绪、TTS、嘴型同步或番茄钟业务。

修改后请重新用应用校验。根目录不要额外放 .md、.psd、.jpg、Thumbs.db 等当前不允许的文件。

原模板说明（其通用格式描述以当前 Schema 为准）：
# Elfin 角色包模板

这是一个可编辑的角色包模板 ZIP。

## 最低可运行资源
- manifest.json
- preview.png
- fallback.png
- animations/idle/ 至少 1 帧

## 建议制作流程
1. 替换 preview.png / fallback.png / animations 下的 PNG
2. 修改 manifest.json 中的 id、名称、描述、动画路径和能力声明
3. 按需修改 persona / dialogue / behavior / emotion / voice / hitarea 下的 JSON
4. 用你的 Elfin 程序导入 ZIP，查看校验结果并修正

## 图片建议
- 画布：512x512 PNG
- fallback / 动画：透明背景
- 序列帧命名：001.png、002.png、003.png

## 重要说明
- 这个模板是通用作者模板。
- 最终字段名和必填项请以你的仓库 docs/character-manifest.schema.json 为准。
- 如果你的当前 Schema 与本模板略有差异，请优先修改 manifest.json 来对齐。

## 目录说明
- animations/idle: 最低必需
- animations/blink happy rest talking: 常用可选动作
- animations/mouth-open / mouth-closed: 嘴型可选资源
- persona: 多语言人格配置示例
- dialogue: 多语言文案示例
- behavior / emotion / voice / hitarea: 高级能力示例


原配置快照，仅供作者参考，不会作为运行配置读取：

behavior/behavior.json
{
  "weights": {
    "idle": 1.0,
    "blink": 1.0,
    "happy": 0.6,
    "rest": 0.5
  },
  "cooldownsMs": {
    "blink": 4000,
    "happy": 8000,
    "rest": 12000
  }
}

dialogue/en-US.json
{
  "greeting": [
    "Hi, I'm ready."
  ],
  "idle": [
    "I'll stay with you quietly."
  ],
  "happy": [
    "Yay!"
  ],
  "pomodoro_complete": [
    "You finished a Pomodoro. Nice work."
  ]
}

dialogue/zh-CN.json
{
  "greeting": [
    "你好呀，我已经准备好啦。"
  ],
  "idle": [
    "我会安静地陪着你。"
  ],
  "happy": [
    "太好啦！"
  ],
  "pomodoro_complete": [
    "完成一个番茄钟了，辛苦啦。"
  ]
}

emotion/emotion.json
{
  "default": "calm",
  "states": [
    "calm",
    "happy",
    "sleepy"
  ],
  "animationMap": {
    "calm": "idle",
    "happy": "happy",
    "sleepy": "rest"
  }
}

hitarea/hitarea.json
{
  "canvasSize": {
    "width": 512,
    "height": 512
  },
  "areas": [
    {
      "id": "head",
      "shape": "ellipse",
      "x": 170,
      "y": 70,
      "width": 172,
      "height": 165
    },
    {
      "id": "body",
      "shape": "rect",
      "x": 190,
      "y": 170,
      "width": 132,
      "height": 220
    }
  ]
}

manifest.json
{
  "id": "replace-with-your-character-id",
  "packageVersion": "1.0.0",
  "schemaVersion": 1,
  "minimumAppVersion": "0.2.0",
  "declaredLevel": "basic",
  "defaultLocale": "zh-CN",
  "locales": {
    "zh-CN": {
      "name": "替换为你的角色名",
      "description": "这是一个 Elfin 角色包模板，请按你的项目 Schema 调整字段。"
    },
    "en-US": {
      "name": "Replace With Your Character Name",
      "description": "This is an Elfin character package template. Adjust fields to match your project schema."
    }
  },
  "assets": {
    "preview": "preview.png",
    "fallback": "fallback.png"
  },
  "animations": {
    "idle": {
      "type": "sequence",
      "path": "animations/idle",
      "fps": 12,
      "loop": true
    },
    "blink": {
      "type": "sequence",
      "path": "animations/blink",
      "fps": 8,
      "loop": false,
      "fallbackTo": [
        "idle"
      ]
    },
    "happy": {
      "type": "sequence",
      "path": "animations/happy",
      "fps": 10,
      "loop": false,
      "fallbackTo": [
        "idle"
      ]
    },
    "rest": {
      "type": "sequence",
      "path": "animations/rest",
      "fps": 8,
      "loop": true,
      "fallbackTo": [
        "idle"
      ]
    },
    "talking": {
      "type": "sequence",
      "path": "animations/talking",
      "fps": 10,
      "loop": true,
      "fallbackTo": [
        "idle"
      ]
    },
    "mouth-open": {
      "type": "static",
      "path": "animations/mouth-open/001.png",
      "fallbackTo": [
        "talking",
        "idle"
      ]
    },
    "mouth-closed": {
      "type": "static",
      "path": "animations/mouth-closed/001.png",
      "fallbackTo": [
        "talking",
        "idle"
      ]
    }
  },
  "capabilities": {
    "persona": true,
    "dialogue": true,
    "behavior": true,
    "emotion": true,
    "voice": true,
    "hitArea": true,
    "lipSync": true
  },
  "profiles": {
    "persona": {
      "zh-CN": "persona/zh-CN.json",
      "en-US": "persona/en-US.json"
    },
    "dialogue": {
      "zh-CN": "dialogue/zh-CN.json",
      "en-US": "dialogue/en-US.json"
    },
    "behavior": "behavior/behavior.json",
    "emotion": "emotion/emotion.json",
    "voice": "voice/voice.json",
    "hitArea": "hitarea/hitarea.json"
  }
}

persona/en-US.json
{
  "name": "Replace With Your Character Name",
  "traits": [
    "gentle",
    "supportive",
    "low-interruption"
  ],
  "speakingStyle": "short, natural, and friendly",
  "relationship": "desktop companion"
}

persona/zh-CN.json
{
  "name": "替换为你的角色名",
  "traits": [
    "温和",
    "陪伴感",
    "轻打扰"
  ],
  "speakingStyle": "简短自然，语气友好",
  "relationship": "桌面陪伴伙伴"
}

voice/voice.json
{
  "recommendedProvider": "windows",
  "recommendedVoice": "replace-with-voice-name",
  "rate": 0,
  "volume": 100
}
